CREATE VIEW GV_$SESSTAT AS select "INST_ID","SID","STATISTIC#","VALUE","CON_ID" from gv$sesstat
/
