CREATE VIEW V_$GOLDENGATE_CAPABILITIES AS select "NAME","COUNT","LAST_USED","CON_ID" from v$goldengate_capabilities
/
