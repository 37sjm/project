CREATE VIEW V_$REDO_DEST_RESP_HISTOGRAM AS select "DEST_ID","TIME","DURATION","FREQUENCY","CON_ID" from v$redo_dest_resp_histogram
/
