CREATE VIEW V_$PROCESS_MEMORY_DETAIL_PROG AS select "PID","SERIAL#","STATUS","CON_ID" from v$process_memory_detail_prog
/
