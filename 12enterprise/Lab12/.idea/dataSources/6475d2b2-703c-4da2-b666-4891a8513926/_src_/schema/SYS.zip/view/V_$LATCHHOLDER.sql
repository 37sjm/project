CREATE VIEW V_$LATCHHOLDER AS select "PID","SID","LADDR","NAME","GETS","CON_ID" from v$latchholder
/
