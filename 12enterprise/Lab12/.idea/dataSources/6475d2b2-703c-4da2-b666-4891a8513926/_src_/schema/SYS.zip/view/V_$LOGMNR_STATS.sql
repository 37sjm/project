CREATE VIEW V_$LOGMNR_STATS AS select "SESSION_ID","NAME","VALUE","CON_ID" from v$logmnr_stats
/
