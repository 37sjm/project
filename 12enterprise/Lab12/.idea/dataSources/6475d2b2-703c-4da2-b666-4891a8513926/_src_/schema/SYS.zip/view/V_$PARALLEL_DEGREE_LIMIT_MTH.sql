CREATE VIEW V_$PARALLEL_DEGREE_LIMIT_MTH AS select "NAME","CON_ID" from v$parallel_degree_limit_mth
/
