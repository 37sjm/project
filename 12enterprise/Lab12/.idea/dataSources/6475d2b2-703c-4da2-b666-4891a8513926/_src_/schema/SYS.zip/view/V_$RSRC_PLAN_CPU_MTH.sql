CREATE VIEW V_$RSRC_PLAN_CPU_MTH AS select "NAME","CON_ID" from v$rsrc_plan_cpu_mth
/
