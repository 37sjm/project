CREATE VIEW V_$SESSTAT AS select "SID","STATISTIC#","VALUE","CON_ID" from v$sesstat
/
