CREATE VIEW V_$MYSTAT AS select "SID","STATISTIC#","VALUE","CON_ID" from v$mystat
/
