CREATE VIEW GV_$ENABLEDPRIVS AS select "INST_ID","PRIV_NUMBER","CON_ID" from gv$enabledprivs
/
