CREATE VIEW V_$BACKUP AS select "FILE#","STATUS","CHANGE#","TIME","CON_ID" from v$backup
/
