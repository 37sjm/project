CREATE VIEW GV_$LATCHHOLDER AS select "INST_ID","PID","SID","LADDR","NAME","GETS","CON_ID" from gv$latchholder
/
