CREATE VIEW V_$SGA AS select "NAME","VALUE","CON_ID" from v$sga
/
