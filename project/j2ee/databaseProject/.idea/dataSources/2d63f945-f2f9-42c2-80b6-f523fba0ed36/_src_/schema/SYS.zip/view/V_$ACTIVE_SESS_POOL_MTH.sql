CREATE VIEW V_$ACTIVE_SESS_POOL_MTH AS select "NAME","CON_ID" from v$active_sess_pool_mth
/
