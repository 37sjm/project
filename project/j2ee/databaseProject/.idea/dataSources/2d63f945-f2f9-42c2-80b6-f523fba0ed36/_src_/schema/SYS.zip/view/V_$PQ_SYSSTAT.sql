CREATE VIEW V_$PQ_SYSSTAT AS select "STATISTIC","VALUE","CON_ID" from v$pq_sysstat
/
