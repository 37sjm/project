CREATE VIEW V_$PX_BUFFER_ADVICE AS select "STATISTIC","VALUE","CON_ID" from v$px_buffer_advice
/
