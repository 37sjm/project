CREATE VIEW COMMON_STARTERS AS select "NAME","POS","NUM","AGE","GS","SUB","GOALS","SHOTS","ASSISTS","FS","FC","TEAMID" from player where player.gs > 10
/
