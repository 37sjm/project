CREATE VIEW V_$ACCESS AS select "SID","OWNER","OBJECT","TYPE","CON_ID" from v$access
/
