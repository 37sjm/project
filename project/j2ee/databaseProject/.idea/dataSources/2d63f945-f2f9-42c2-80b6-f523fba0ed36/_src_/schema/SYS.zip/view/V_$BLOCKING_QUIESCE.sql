CREATE VIEW V_$BLOCKING_QUIESCE AS select "SID","CON_ID" from v$blocking_quiesce
/
