CREATE VIEW GV_$NLS_PARAMETERS AS select "INST_ID","PARAMETER","VALUE","CON_ID" from gv$nls_parameters
/
