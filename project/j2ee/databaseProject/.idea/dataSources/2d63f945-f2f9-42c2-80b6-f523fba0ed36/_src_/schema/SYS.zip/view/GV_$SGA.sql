CREATE VIEW GV_$SGA AS select "INST_ID","NAME","VALUE","CON_ID" from gv$sga
/
